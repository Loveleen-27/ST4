// creating an array and passing the number, questions, options, and answers
let questions = [
    {
     numb: 1,
    // question: "What does HTML stand for?",
    // answer: "Hyper Text Markup Language",
    // options: [
    //   "Hyper Text Preprocessor",
    //   "Hyper Text Markup Language",
    //   "Hyper Text Multiple Language",
    //   "Hyper Tool Multi Language"
    // ]


    question: "Which of the following is the correct identifier?",
    answer:  "$var_name",
    options: [
      "$var_name",
       "$Var_name",
        "varname@",
        "None of the above"
      ]
  },
    {
     numb: 2,
    // question: "What does CSS stand for?",
    // answer: "Cascading Style Sheet",
    // options: [
    //   "Common Style Sheet",
    //   "Colorful Style Sheet",
    //   "Computer Style Sheet",
    //   "Cascading Style Sheet"
    // ]

    question: "Which type of JavaScript language is _?",
    answer: "Object-Oriented",
    options: ["Object-Oriented", "Object-Based", "Assembly-language","High-level"],

  },
    {
    numb: 3,
    // question: "What does PHP stand for?",
    // answer: "Hypertext Preprocessor",
    // options: [
    //   "Hypertext Preprocessor",
    //   "Hypertext Programming",
    //   "Hypertext Preprogramming",
    //   "Hometext Preprocessor"
    // ]
    question: "The CSS property used to control the element's font-size is -",
   
    answer: "font-size",
    options: ["text-style", "text-size", "font-size", "None of the above"],
  },
    {
    numb: 4,
    // question: "What does SQL stand for?",
    // answer: "Structured Query Language",
    // options: [
    //   "Stylish Question Language",
    //   "Stylesheet Query Language",
    //   "Statement Question Language",
    //   "Structured Query Language"
    // ]
    question: "Which of the following is not a value of the font-variant property in CSS?",
   
   answer:  "large-caps",
   options: ["normal", "small-caps", "large-caps", "inherit"],
  },
    {
    numb: 5,
    // question: "What does XML stand for?",
    // answer: "eXtensible Markup Language",
    // options: [
    //   "eXtensible Markup Language",
    //   "eXecutable Multiple Language",
    //   "eXTra Multi-Program Language",
    //   "eXamine Multiple Language"
    // ]
    question: " Which of the following is used for implementing the late binding?",
   
    answer: "Virtual Functions",
    options: ["Operator Functions", "Constant Functions", "Virtual Functions", "Both A and B"],
  },
  {
    numb:6,
    question: "Which of the following features is required to be supported by the programming language to become a pure object-oriented programming language?",
   
    answer: "All of the above",
    options: ["Encapsulation", "Inheritance", "Polymorphism", "All of the above"],

  },

  {
    numb:7,
    question: "Which of the following is the correct response by the interpreter in a jump statement when an exception is thrown?",
   
    answer: "The interpreter will jump to the one of the nearest enclosing exception handler", 
    options: ["The interpreter will jump to the one of the nearest enclosing exception handler", "The interpreter will throw another exception", "The interpreter will stop working", "The interpreter throws an error"],
  },

  {
    numb:8,
    question: "Which of the following statements is correct regarding the object-oriented programming concept in Python?",
   
    answer:  "Objects are real-world entities while classes are not real",
    options: ["Classes are real-world entities while objects are not real", "Objects are real-world entities while classes are not real", "Both objects and classes are real-world entities", "All of the above"], 
  },
  















  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];